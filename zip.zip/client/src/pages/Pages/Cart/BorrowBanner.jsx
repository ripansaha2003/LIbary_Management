import React from "react";

const BorrowBanner = () => {
  return (
    <div className="home-banner" style={{ fontFamily: "poppins" }}>
      <>Detail Of Borrowed User</>
    </div>
  );
};

export default BorrowBanner;
